This project was created by ronald ngoda
email:ronniengoda@gmail.com
website:ronaldngoda.is-best.net
phone:+254708344101



===========ABOUT PROJECT============
This is an online gate pass management system.With this, management of visitors and activities at the gate of an organisation or institution is absolutely easy.The system has a wide array of interesting features like
You can register gate guards as the admin who will be managing different gates
Management of visitors,individual visitors and group visitors.You can keep track of the entry and exit times of all visitors including staff
You can register staff members also into the system
Capture vehicle details
Capture luggage details
Approve or disapprove visitors from getting into the gate and provide reasons why
An intuitive dashboard that gives you detailed information about the data in the system
You can run complex queries on all data sets to get specific information at a click of a button
Management and record keeping of gate pass details is very easy as the system uses a central database to keep details of different gates of the same institution. 
Print reports and any information from the system for further reference

INSTALLATION
import the gpms_db.sql file into your database named gpms_db and all is done you are set to go...
login admin/admin